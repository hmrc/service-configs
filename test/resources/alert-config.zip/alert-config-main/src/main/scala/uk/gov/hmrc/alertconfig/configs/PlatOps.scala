package uk.gov.hmrc.alertconfig.configs

import uk.gov.hmrc.alertconfig.{HttpStatus, HttpStatusThreshold}
import uk.gov.hmrc.alertconfig.builders.{AlertConfig, AlertConfigBuilder, EnvironmentAlertBuilder, TeamAlertConfigBuilder}
import uk.gov.hmrc.alertconfig.builders.TeamAlertConfigBuilder.teamAlerts

object PlatOps extends AlertConfig {

  private val testAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "test",
  )).withExceptionThreshold(10)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withLogMessageThreshold("Number of in progress files exceeds maximum", 1)
    .withLogMessageThreshold("Failed to route envelope", 10)
    .withHandlers("platops")


  private val fileUploadAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "file-upload",
    "file-upload-frontend"
  )).withExceptionThreshold(10)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withLogMessageThreshold("Number of in progress files exceeds maximum", 1)
    .withLogMessageThreshold("Failed to route envelope", 10)
    .withHandlers("platops")

  private val upscanAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "upscan-initiate",
    "upscan-verify",
    "upscan-notify",
    "upscan-upload-proxy"
  )).withExceptionThreshold(10)
    .withHttp5xxPercentThreshold(0.01)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withHandlers("platops")

  private val fileTransmissionAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "file-transmission"
  )).withExceptionThreshold(10)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 5))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withHandlers("platops")

  private val objectStoreAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "object-store",
    "object-store-admin-frontend"
  )).withExceptionThreshold(10)
    .withHttp5xxPercentThreshold(0.01)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withLogMessageThreshold("Unexpected AWS error", 1)
    .withHandlers("platops")

  private val internalAuthAlertConfig: TeamAlertConfigBuilder = teamAlerts(Seq(
    "internal-auth",
    "internal-auth-frontend",
    "internal-auth-admin-frontend"
  )).withExceptionThreshold(10)
    .withHttp5xxPercentThreshold(0.01)
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_500, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_502, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_503, 1))
    .withHttpStatusThreshold(HttpStatusThreshold(HttpStatus.HTTP_STATUS_504, 1))
    .withHandlers("platops")

  private val platApps: TeamAlertConfigBuilder = teamAlerts(Seq(
    "catalogue-frontend",
    "teams-and-repositories",
    "service-dependencies",
    "service-configs",
    "leak-detection",
    "user-management-auth",
    "shutter-api",
    "releases",
    "artefact-processor",
    "build-metrics",
    "health-indicators",
    "slack-notifications",
    "internal-auth",
    "internal-auth-frontend",
    "internal-auth-admin-frontend",
    "platform-initiatives",
    "releases-api"
  ))
    .isPlatformService(true)
    .withExceptionThreshold(15)
    .withHttp5xxPercentThreshold(5)
    .withHandlers("platops")

  override val alertConfig: Seq[AlertConfigBuilder] =  Seq(
    fileUploadAlertConfig,
    upscanAlertConfig,
    fileTransmissionAlertConfig,
    objectStoreAlertConfig,
    internalAuthAlertConfig,
    platApps
  ).flatMap(_.build)

  // PlatApps services logs are available only in Production and QA.
  override def environmentConfig: Seq[EnvironmentAlertBuilder] = Seq(
    EnvironmentAlertBuilder("platops").inExternalTest().inProduction()
  )
}
