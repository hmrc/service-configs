package uk.gov.hmrc.alertconfig

import java.io.{File, PrintWriter}

import uk.gov.hmrc.alertconfig.AlertConfigs._
import uk.gov.hmrc.alertconfig.ObjectScanner.loadAll
import uk.gov.hmrc.alertconfig.builders.{AlertConfig, AlertConfigBuilder, AllEnvironmentAlertConfigBuilder, Environment}


object AlertConfigMain {

  def main(args: Array[String]) {
    run()
  }

}

class Logger {
  def info(st: String) = println("[INFO] " + st)

  def debug(st: String) = println("[DEBUG] " + st)

  def warn(st: String) = println("[WARN] " + st)
}


object AlertConfigs {

  val log = new Logger()

  def run() {
    val alertConfigs: Set[AlertConfig] = loadAll[AlertConfig]()

    val output = new File("target", "output")
    recursiveDelete(output)

    log.debug(s"Generating alert configs in $output...")

    val environmentConfigBuilders = alertConfigs.flatMap(_.environmentConfig)
    val allEnvironmentConfig = AllEnvironmentAlertConfigBuilder.build(environmentConfigBuilders)

    allEnvironmentConfig.foreach( tup => printToFile(handlerFile(output, tup._1)){ writer =>
      writer.println(tup._2.prettyPrint)
    } )

    val alertConfigBuilders = alertConfigs.flatMap(_.alertConfig)
    val alertConfigBuildersMap: Map[AlertConfigBuilder, Option[String]] = alertConfigBuilders.map(b => b -> b.build).toMap
    val viableAlertConfigBuilders = alertConfigBuildersMap.filter(_._2.isDefined)

    viableAlertConfigBuilders.foreach(entry => printToFile(file(output, entry._1)) { writer =>
      writer.println(entry._2.get)
    })
  }

  private def handlerFile(output: File, environment: Environment): File = {
    new File(new File(output, "handlers"), s"${environment}.json")
  }

  private def file(output: File, builder: AlertConfigBuilder): File = {

    new File(new File(output, "configs"), s"${builder.serviceName}.json")
  }

  private def printToFile(file: File)(op: PrintWriter => Unit) {
    file.getParentFile.mkdirs()
    val printWriter = new PrintWriter(file)
    try {
      op(printWriter)
    } finally {
      printWriter.close()
    }
  }

  private def recursiveDelete(file: File) {

    if (file.exists()) {
      if (file.isDirectory) {
        file.listFiles.foreach(recursiveDelete)
      }

      file.delete
    }
  }
}


