import sys
import re
import os
import yaml
from pathlib import Path

environment_paths = [Path("prod"), Path("qa"), Path("platapps-live"), Path("platapps-labs")]

grant_keys = set(['grantees', 'permissions'])
resource_definition_keys = set(['resourceType', 'actions', 'granteeTypes'])
permission_keys = set(['resourceType', 'resourceLocation', 'actions'])

valid_grantee_types = set(['service', 'user', 'members-of-team', 'owners-of-service'])
placeholders = {
    "service": ["service", "owners-of-service"],
    "team": ["members-of-team"]
}


if len(sys.argv) > 1:
    environment_paths = map(lambda environment: Path(environment), sys.argv[1:])


def find_permissible_actions(resource_type):
    for resource_definition in resource_definitions:
        if resource_definition['resourceType'] == resource_type:
            return resource_definition['actions']


def find_permissible_grantee_types(resource_type):
    for resource_definition in resource_definitions:
        if resource_definition['resourceType'] == resource_type:
            return resource_definition['granteeTypes']

# there shouldn't be spaces between hypenated or dot separated words on certain fields
missing_commas_validation_keys = set({'service', 'owners-of-service', 'user'})
def validate_no_missing_commas(grant):

    def has_spaces_between_values(grantees) -> bool:
        return next(filter(lambda value: ' ' in value.strip(), grantees), False)

    is_valid = True
    grantees = grant['grantees']
    keys_to_validate = {k for k in grantees.keys() if k in missing_commas_validation_keys}
    for gt in keys_to_validate:
        if has_spaces_between_values(grantees[gt]):
            is_valid = False
            print("Failed - {}: Grantees '{}' section is missing commas.\nValues: '{}'\n"
                .format(grants_file_path, gt, grantees[gt]))
    if not is_valid:
        sys.exit(-1)

def validate_permissible_grantee_for_placeholder(grants_file_path, placeholder, grant, id_):
    grantee_types = placeholders.get(placeholder)
    grantees = grant['grantees']
    for gt in grantees.keys():
        if gt not in grantee_types:
            print("Failed - {}: placeholder {} can only be used with a grantee of {}:*"
                .format(grants_file_path, placeholder, grantee_type))
            sys.exit(-1)


def validate_grantee_types(grants_file_path, resource_type, grant):
    permissible_grantee_types = find_permissible_grantee_types(resource_type)
    for grantee_type in grant['grantees'].keys():
        if grantee_type not in permissible_grantee_types:
            print(
                "Failed - {}: grant {} specifies granteeType {} which is invalid for resource_type {}. permissible types are {}".format(
                    grants_file_path, grant, grantee_type, resource_type, permissible_grantee_types))
            sys.exit(-1)


def validate_resource_location(resource_location):
    if resource_location.startswith('/') or resource_location.endswith('/'):
        print("Failed - {}: resources should not begin or end with a slash {}", grants_file_path, resource_location)
        sys.exit(-1)


def load_resource_definitions():
    resource_definitions_file_path = environment_path / "resource-definitions.yaml"
    with open(resource_definitions_file_path, 'r') as resource_definitions_file:
      resource_definitions = yaml.safe_load(resource_definitions_file)
    for resource_definition in resource_definitions:
        if set(resource_definition.keys()) != resource_definition_keys:
            print("Failed - {}: resource_definition {} has unexpected keys {}".format(resource_definitions_file_path, resource_definition, set(resource_definition.keys()) - resource_definition_keys))
            sys.exit(-1)
        for grantee_type in resource_definition['granteeTypes']:
            if grantee_type not in valid_grantee_types:
                print("Failed - {}: grant {} has unexpected grantees {}. valid grantee types are {}".format(resource_definitions_file_path, resource_definition, grantee_type, valid_grantee_types))
                sys.exit(-1)

    if len(set(map(lambda x: x['resourceType'], resource_definitions))) != len(resource_definitions):
        print("Failed - {}: Duplicate resource definitions".format(resource_definitions_file_path))
        sys.exit(-1)

    return resource_definitions


def load_grants():
    all_grants = list()
    with open(environment_path / "index.yaml", 'r') as indexf:
      index = yaml.safe_load(indexf)
    for f in index["grants_files"]:
        grants_file_path = environment_path / f
        with open(grants_file_path, 'r') as f2:
            grants = yaml.safe_load(f2)
            for grant in grants:
                if set(grant.keys()) != grant_keys:
                    print("Failed - {}: grant {} has unexpected keys {}".format(grants_file_path, grant, set(grant.keys()) - grant_keys))
                    sys.exit(-1)
                if not set(grant['grantees'].keys()).issubset(valid_grantee_types):
                    print("Failed - {}: grant {} has unexpected grantees {}. valid grantee types are {}".format(grants_file_path, grant, set(grant['grantees'].keys()) - valid_grantee_types, valid_grantee_types))
                    sys.exit(-1)
                for permission in grant['permissions']:
                    if set(permission.keys()) != permission_keys:
                        print("Failed - {}: grant {} has unexpected permissions keys {}".format(grants_file_path, grant, set(permission.keys()) - permission_keys))
                        sys.exit(-1)
            all_grants.append((grants_file_path, grants))
    return all_grants


for environment_path in environment_paths:

    resource_definitions = load_resource_definitions()

    all_grants = load_grants()

    for (grants_file_path, grants) in all_grants:
      for grant in grants:

        validate_no_missing_commas(grant)

        for permission in grant['permissions']:
            resource_type = permission['resourceType']
            resource_location = permission['resourceLocation']
            actions = permission['actions']

            permissible_actions = find_permissible_actions(resource_type)
            if permissible_actions is None:
                print("Failed - {}: grant {} refers to undefined resource_type {}".format(grants_file_path, grant, resource_type))
                sys.exit(-1)

            for action in actions:
                if action != "*" and action not in permissible_actions:
                    print(
                        "Failed - {}: grant {} specifies action {} which is invalid for resource_type {}. permissible actions are {}".format(
                            grants_file_path, grant, action, resource_type, permissible_actions))
                    sys.exit(-1)

            validate_grantee_types(grants_file_path, resource_type, grant)

            validate_resource_location(resource_location)

            placeholder_match = re.search(r"{(\w+)}", resource_location)
            if placeholder_match is not None:
                placeholder = placeholder_match.group(1)
                if placeholder not in placeholders:
                    print("Failed - {}: Unrecognised variable found {{{}}}, only values {} should be surrounded in {{}}".format(
                        grants_file_path, placeholder, ", ".join(placeholders.keys())))
                    sys.exit(-1)
                else:
                    validate_permissible_grantee_for_placeholder(grants_file_path, placeholder, grant, "*")


print("Yaml Grants and ResourceTypes passed validation")
