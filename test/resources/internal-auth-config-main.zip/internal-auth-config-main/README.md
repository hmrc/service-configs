
# internal-auth-config

This project provides resource definitions and grants configuration for https://github.com/hmrc/internal-auth. To understand how these can be configured please refer to [configuring permissions](https://github.com/hmrc/internal-auth#configuring-permissions). 

## MDTP

| Environment   |   Directory   |
|---------------|:-------------:|
| Development   |      qa       | 
| Qa            |      qa       | 
| Staging       |      qa       | 
| ExternalTest  |     prod      | 
| Production    |     prod      |

## PlatOps

| Environment   |   Directory   |
|---------------|:-------------:|
| platapps-labs | platapps-labs |
| platapps-live | platapps-live |


After editing `resource-definitions.yaml` or `grants.yaml` for an environment, you can run some rudimentary checks with:

```bash
pip install -r requirements.txt
python validator.py
```

# Setup

The project has 2 versions of the configuration files for MDTP in the respective directories /qa and /prod and 2 for PlatOps in /platapps-labs and /platapps-live.
Which configuration is used is based on internal-auth.yaml in app-config-${env} or app-config-platops-labs for the new PlatOps labs environment.

```yaml
hmrc_config:
  auth.config_dir: "hmrc/internal-auth-config/HEAD/qa"
```
