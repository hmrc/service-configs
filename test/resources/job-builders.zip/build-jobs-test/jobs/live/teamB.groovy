package live

// ============= Team folder ========================================

String TEAM = 'teamB'

new TeamFolderBuilder(TEAM)
        .build(this as DslFactory)


new MvnMicroserviceJobBuilder(TEAM, 'service-five')
        .andRunMvnWith('test')
        .andUploadSlug('.', 'test', 'service-five')
        .withPublishers(junitPublisher(), owaspPublisher())
        .build(this as DslFactory)


new MvnMicroserviceJobBuilder(TEAM, 'service-six', JavaType.OPENJDK_JRE8)
        .andRunMvnWith('test')
         .andUploadSlug('.', 'test', 'service-six')
        .andUploadSlug('.', 'test', 'service-six-slug')
        .withPublishers(junitPublisher(), owaspPublisher())
        .build(this as DslFactory)


new PipelineJobBuilder(FOLDER, "test")
        .buildMicroservice("test")
        .andThenDeployTo(test, test, test)
        .andThenRun("test", "test")
        .andThenDeployOrchestratorlessInParallelTo([TEST, TEST])
        .build(this as DslFactory)

new BrowserTestsJobBuilder(FOLDER, "test", "test")
        .withCommand("test")
        .withBrowser(BrowserType.Chrome_LATEST)
        .withGithubPushTrigger()
        .withoutJUnitReports()
        .withoutCucumberReport()
        .withPublishers(sbtScreenshotPublisher())
        .build(this as DslFactory)

new MvnMicroserviceJobBuilder(team, "service-seven")
        .andRunMvnWith('test')
        .withPublishers(junitPublisher())
        .build(this as DslFactory)

new MvnAemJobBuilder(TEAM,'service-eight','test')
        .andInitateAem()
        .andRunMvnWith('test')
        .andStartAem()
        .andArchiveAem()
        .andUploadSlug('test','test','service-eight-slug')
        .andRemoveTgz()
        .build(this as DslFactory)