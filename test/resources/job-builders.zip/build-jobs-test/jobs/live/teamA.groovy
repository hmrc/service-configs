package live

// ============= Team folder ========================================

String TEAM = 'teamA'

new TeamFolderBuilder(TEAM)
        .build(this as DslFactory)


new MvnMicroserviceJobBuilder(TEAM, 'service-one')
        .andRunMvnWith('test')
        .andUploadSlug('.', 'test', 'service-one')
        .withPublishers(junitPublisher(), owaspPublisher())
        .build(this as DslFactory)


new MvnMicroserviceJobBuilder(TEAM, 'service-two', JavaType.OPENJDK_JRE8)
        .andRunMvnWith('test')
         .andUploadSlug('.', 'test', 'service-two')
        .andUploadSlug('.', 'test', 'service-two-slug')
        .withPublishers(junitPublisher(), owaspPublisher())
        .build(this as DslFactory)


new PipelineJobBuilder(FOLDER, "test")
        .buildMicroservice("test")
        .andThenDeployTo(test, test, test)
        .andThenRun("test", "test")
        .andThenDeployOrchestratorlessInParallelTo([TEST, TEST])
        .build(this as DslFactory)

new BrowserTestsJobBuilder(FOLDER, "test", "test")
        .withCommand("test")
        .withBrowser(BrowserType.Chrome_LATEST)
        .withGithubPushTrigger()
        .withoutJUnitReports()
        .withoutCucumberReport()
        .withPublishers(sbtScreenshotPublisher())
        .build(this as DslFactory)

new MvnMicroserviceJobBuilder(team, "service-three")
        .andRunMvnWith('test')
        .withPublishers(junitPublisher())
        .build(this as DslFactory)

new MvnAemJobBuilder(TEAM,'service-four','test')
        .andInitateAem()
        .andRunMvnWith('test')
        .andStartAem()
        .andArchiveAem()
        .andUploadSlug('test','test','service-four-slug')
        .andRemoveTgz()
        .build(this as DslFactory)