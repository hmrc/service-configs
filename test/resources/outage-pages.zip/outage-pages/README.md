# Outage Pages

This repo contains HTML files to be displayed when a frontend service has been shuttered. 

Shuttering is the process of closing down a service temporarily (usually while maintenance etc is going on). During this 
time any users to the service will receive a static shuttered page. This will usually tell them why the service is 
currently unavailable, and the expected time it will be back up and running.

It is designed to be used for scenarios where there is a need to remove users access to a service due to planned 
maintenance, or perhaps security, political or reputational reasons. It gives teams the ability to provide a nice
message to users during these removals of access.

For more info on shuttering, see [here](https://confluence.tools.tax.service.gov.uk/display/DTRG/Shuttering+your+service).
 
## TL;DR:

Teams can upload their own shuttering content to this git repository (“https://github.com/HMRC/outage-pages/).
The content in “index.html” for each service can be tailored and committed, and will be available as the shuttering content within 1 to 2 minutes.
The automated system has a restriction of a single shuttering page - We now *only* accept index.html; additional pages with alternative names will be ignored by the shuttering system. 

Each service should have a single, unique outage page (aside from a welsh specific variant if required).

## Creating a new outage-page for your service

If you're adding the outage-page for a new service, you need to:

1. Clone this repo: `git clone git@github.com:hmrc/outage-pages.git` and create a new branch for changes.
2. Create a directory with your service name under the relevant environment
   e.g.  
   `mkdir production/service-name `
   > This name must match _exactly_ with your service name and shutter switches, as configured in the [`mdtp-frontend-routes`](https://github.com/hmrc/mdtp-frontend-routes#configuring-your-service-for-shuttering)
3. Create a file called `index.html` with the content to be served when your service is shuttered in the directory you created
4. Run the validation tests to ensure your modifications are in the correct format: `./gradlew clean test`
5. If all tests pass, commit and push your branch
   ```
   git commit -m Added shuttering content for service myservice  
   git push origin mybranch
   ```
6. Create a PR in Github, have someone review it, and if all okay then merge.

The outage-pages will be available via the Catalogue shuttering mechanism instantly (as they're pulled on demand). The legacy Jenkins mechanism
will have them available within 10 minutes.

### Dynamic / Templated outage-page content
If you are shuttering via the Catalogue, we have added support for a special element ID that you are free to use within 
your outage-page. You can specify this ID on any element, and then when shuttering whatever html content exists within it 
will be displayed to use, with the option to customise it as required.

The ID is called 'templatedMessage' and an example configuration would look like this:

`<p>You&rsquo;ll be able to use the Help to Save service from <span id="templatedMessage">7am on Sunday 30 September 2018.</span></p>`

When you shutter via the Catalogue, we retrieve the outage-pages from Github on demand and pull out the value of this ID if we find it, 
allowing you to override the message that gets inserted. Any content that you specify when shuttering will be injected as the value in the 
index.html file, by updating the content of the element with that ID.

You can use HTML content here, and the ID is not limited to being specified on a span as shown above. In the example above, the ID 
could be specified directly on the '<p>' tag for example, though we advise keeping it simple and restricting it to the smallest possible 
scope as shown. This way the value pulled out and editable will just be the span, with the value ‘7am on Sunday 30 September 2018.’.

> N.B. The same outage-page is still synced with no-changes and used if shuttering via Jenkins (which we now consider legacy). 
You can update your outage-page to take advantage of this special ID without breaking the legacy shuttering mechanism; the user 
will just be rendered a page where one of the elements has an extra ID, that will just be ignored with no impact.

# What does the shuttering mechanism achieve?
* Reducing the time to deploy shuttering content:

  A service can be shuttered in minutes, using a user-friendly error page. A full audit trail of shuttering actions is recorded.

* Providing a robust content mechanism:

  Shuttering content can be updated without having to modify any other repositories, or the nginx configuration.  
  For the Catalogue, the files are pushed to S3 on demand. For legacy Jenkins shuttering, files are automatically uploaded from the repository 
  to an S3 bucket, then synced to the frontend proxies.  
  It is very hard to break anything under this mechanism.  

* Simplifying frontend routing:

  Configuring shuttering has been standardised for all services. As part of the changes to add shuttering to the Catalogue, we
  also enforce more rigid alignment to our best practices. This reduces the maintenance burden, and raises stability.  

# Where is the content served from?

Content is served from an AWS S3 bucket, which is periodically synced down on the proxy hosts.

This is the same mechanism as the shutter switches and frontend routes.  

Details of the switch mechanism are available in the core documentation:
https://confluence.tools.tax.service.gov.uk/display/DTRG/Shuttering+your+service

The mechanism itself looks like this:
https://confluence.tools.tax.service.gov.uk/display/DTRG/Shuttering+your+service#Shutteringyourservice-Howdoestheshutteringservicework?  

# What environments can services be shuttered in?
Development, Integration, QA, Staging, External Test, and Production

# What happens if I shutter my service with no content?
Ideally your service _should_ provide a custom outage-page, so that your users are given a friendly message as to why it is unavailable.

If your service does not have an outage page (or it is configured incorrectly) then your users will receive the default page, providing
the configuration for your service returns status code 503 for the [mdtp-frontend-routes configuration](https://github.com/hmrc/mdtp-frontend-routes), 

> The default page just states there are “technical difficulties”. Needless to say this content is extremely generic and not especially desirable for any service.

# Where can I get more information on the shuttering process?
For the full documentation, see [here](https://confluence.tools.tax.service.gov.uk/display/DTRG/Shuttering+your+service).

# Where do I send feedback or ask questions?
If you have any questions, comments, or feedback on the shuttering mechanism you can send us a message in [#team-platops](https://hmrcdigital.slack.com/messages/team-platops/)


