appender("STDOUT", ConsoleAppender) {
    encoder(PatternLayoutEncoder) {
        pattern = "%d [%thread] %-5level %logger{15} - %msg%n"
    }
}
root(DEBUG, ["STDOUT"])
