package uk.gov.hmrc

import groovy.io.FileType
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import java.nio.file.Path

import static java.nio.file.Files.exists

class OutagePagesLocalResolver {

    private static final Logger LOGGER = LoggerFactory.getLogger(OutagePagesLocalResolver)

    List<Path> getOutagePageFiles(final Path environmentPath) {
        if(!exists(environmentPath)) {
            throw new FileNotFoundException("Environment directory: '${environmentPath.toString()}' does not exist.")
        }

        final List<Path> outagePages = []
        environmentPath.eachFileRecurse(FileType.FILES) { outagePageFile ->
            outagePages << outagePageFile
        }

        LOGGER.info("${outagePages.size()} outage pages found in path '${environmentPath.toAbsolutePath().toString()}'")
        return outagePages
    }
}
