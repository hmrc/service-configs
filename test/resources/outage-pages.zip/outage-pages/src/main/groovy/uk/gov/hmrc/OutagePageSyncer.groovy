package uk.gov.hmrc

import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model.DeleteObjectsRequest
import com.amazonaws.services.s3.model.ObjectListing
import com.amazonaws.services.s3.model.S3ObjectSummary
import com.amazonaws.services.s3.transfer.MultipleFileUpload
import com.amazonaws.services.s3.transfer.TransferManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import java.nio.file.Path
import java.nio.file.Paths
import java.util.stream.Collector
import java.util.stream.Collectors

class OutagePageSyncer {

    private static final Logger LOGGER = LoggerFactory.getLogger(OutagePageSyncer)

    private final AmazonS3 amazonS3Client

    private final OutagePagesLocalResolver localOutagePagesDAO
    private final OutagePagesLocalResolver outagePagesLocalResolver
    private final TransferManager transferManager

    OutagePageSyncer(final AmazonS3 amazonS3Client,
                     final TransferManager transferManager,
                     final OutagePagesLocalResolver outagePagesLocalResolver) {
        this.amazonS3Client = amazonS3Client
        this.transferManager = transferManager
        this.outagePagesLocalResolver = outagePagesLocalResolver
    }

    void syncOutagePages(final String environment,
                         final String outagePagesS3Bucket,
                         final String outagePagesS3SyncBasePath) {

        final String keyPrefix = "${outagePagesS3SyncBasePath}/${environment}"

        LOGGER.info("Processing outage pages for '${environment}' environment.")
        LOGGER.info("Target bucket is '${outagePagesS3Bucket}'")
        LOGGER.info("Base path to sync to within bucket is '${keyPrefix}'")

        final Path environmentDirectory = Paths.get(environment)
        final List<Path> localOutagePages = outagePagesLocalResolver.getOutagePageFiles(environmentDirectory)
        final Map<String, Path> localOutagePagesMappedBySyncPath = localOutagePages.stream()
                                                                                   .collect(Collectors.toMap({"${outagePagesS3SyncBasePath}/${it.toString()}"},
                                                                                                             {it}) as Collector<? super Path, Object, Object>)

        final ObjectListing remoteOutagePages = amazonS3Client.listObjects(outagePagesS3Bucket, keyPrefix)
        final Map<String, S3ObjectSummary> remoteObjectsMappedByKey = remoteOutagePages.objectSummaries
                                                                                       .stream()
                                                                                       .collect(Collectors.toMap({it.key},
                                                                                                                 {it}) as Collector<? super S3ObjectSummary, Object, Object>)

        final Set<String> newOutagePageKeys = localOutagePagesMappedBySyncPath.keySet() - remoteObjectsMappedByKey.keySet()
        final Set<String> existingOutagePageKeys = localOutagePagesMappedBySyncPath.keySet() - newOutagePageKeys
        final Set<String> staleOutagePageKeys = remoteObjectsMappedByKey.keySet() - localOutagePagesMappedBySyncPath.keySet()

        if(newOutagePageKeys) {
            final List<String> sortedKeys = (newOutagePageKeys as List).sort()
            LOGGER.info("The following ${newOutagePageKeys.size()} outage pages are new and will be synchronised to the remote location: \n\t${sortedKeys.join('\n\t')}")

            final List<File> newOutagePages = localOutagePagesMappedBySyncPath.entrySet()
                                                                              .stream()
                                                                              .filter({Map.Entry e -> newOutagePageKeys.contains(e.getKey())})
                                                                              .map({Map.Entry e -> e.getValue()})
                                                                              .map({Path p -> p.toFile()})
                                                                              .collect()

            final MultipleFileUpload newOutagePagesUpload = transferManager.uploadFileList(outagePagesS3Bucket,
                                                                                           keyPrefix,
                                                                                           environmentDirectory.toFile(),
                                                                                           newOutagePages)
            newOutagePagesUpload.waitForCompletion()
            LOGGER.info("New outage page synchronisation was successful.")
        }
        else {
            LOGGER.info("There are no new outage pages which need to be synchronised to the remote location.")
        }

        if(existingOutagePageKeys) {
            final List<String> sortedKeys = (existingOutagePageKeys as List).sort()
            LOGGER.info("The following ${existingOutagePageKeys.size()} outage pages already exist remotely and will be re-synchronised to the remote location (in case any content updates have been made locally): \n\t${sortedKeys.join('\n\t')}")

            final List<File> existingOutagePages = localOutagePagesMappedBySyncPath.entrySet()
                                                                                   .stream()
                                                                                   .filter({ Map.Entry e -> existingOutagePageKeys.contains(e.getKey()) })
                                                                                   .map({ Map.Entry e -> e.getValue() })
                                                                                   .map({ Path p -> p.toFile() })
                                                                                   .collect()


            final MultipleFileUpload existingOutagePagesUpload = transferManager.uploadFileList(outagePagesS3Bucket,
                                                                                                keyPrefix,
                                                                                                environmentDirectory.toFile(),
                                                                                                existingOutagePages)
            existingOutagePagesUpload.waitForCompletion()
            LOGGER.info("Existing outage page synchronisation was successful.")
        }
        else {
            LOGGER.info("There are no existing outage pages which need to be re-synchronised to the remote location.")
        }

        if(staleOutagePageKeys) {
            final List<String> sortedKeysToRemove = (staleOutagePageKeys as List).sort()
            LOGGER.info("The following ${staleOutagePageKeys.size()} outage pages will be be removed from the remote location: \n\t${sortedKeysToRemove.join('\n\t')}")
            amazonS3Client.deleteObjects(new DeleteObjectsRequest(outagePagesS3Bucket).withKeys(*sortedKeysToRemove))
            LOGGER.info("Remote outage page deletion was successful.")
        }
        else {
            LOGGER.info("There are no outage pages which need to be removed from the remote location.")
        }

        transferManager.shutdownNow(true)
        LOGGER.info("Successfully synced outage pages for '${environment}' environment.")
    }
}
