package uk.gov.hmrc

import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.transfer.TransferManager

class OutagePageSyncRunner {

    static void main(String[] args) {
        final AmazonS3 amazonS3 = AmazonS3ClientBuilder.defaultClient()
        final TransferManager transferManager = new TransferManager(amazonS3)
        final OutagePagesLocalResolver outagePagesLocalResolver = new OutagePagesLocalResolver()
        final OutagePageSyncer outagePageSyncer = new OutagePageSyncer(amazonS3,
                                                                       transferManager,
                                                                       outagePagesLocalResolver)
        outagePageSyncer.syncOutagePages(System.getenv("ENVIRONMENT"),
                                         System.getenv("OUTAGE_PAGES_BUCKET"),
                                         System.getenv("OUTAGE_PAGES_SYNC_BASE_PATH"))
    }


}
