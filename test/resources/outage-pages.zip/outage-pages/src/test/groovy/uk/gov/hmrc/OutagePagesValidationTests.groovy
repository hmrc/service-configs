package uk.gov.hmrc

import groovy.io.FileType
import org.junit.Test
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import java.util.stream.Stream

import static org.junit.Assert.fail

class OutagePagesValidationTests extends Specification {

    private static final Logger LOGGER = LoggerFactory.getLogger(OutagePagesValidationTests)

    // This is the list of environments for which directories exist in this repository.
    private static final String DEFINED_ENVIRONMENT_NAMES = "development,externaltest,integration,production,staging,qa"

    // This is the list of allowed language specific directories
    @Shared
    final static List<String> allowedLanguageDirs = ["cy"]

    @Shared
    final static List<String> environmentNames = (System.getenv("ENVIRONMENTS") ?: DEFINED_ENVIRONMENT_NAMES).split(",")

    @Shared
    final static List<File> environmentDirectories = validateEnvironments(environmentNames)

    @Shared
    final static List<File> outagePages = listOutagePages(environmentDirectories)

    @Shared
    final static Closure<List<File>> listDirectDescendantDirectories = { File directory ->
        List<File> directDescendantDirectories = []
        directory.eachDir { directDescendantDirectories.add(it) }
        return directDescendantDirectories
    }

    @Shared
    final static List<File> outagePageDirectories = listOutagePageDirectories(environmentDirectories)

    @Test
    @Unroll
    void 'there are no "#environmentDirectory.name" outage pages which exist outside of a service folder'(File environmentDirectory) {

        given:
        final List<File> outagePagesOutsideOfAServiceFolder = []
        environmentDirectory.eachFile(FileType.FILES) { outagePagesOutsideOfAServiceFolder.add(it) }

        expect:
        !outagePagesOutsideOfAServiceFolder

        where:
        environmentDirectory << environmentDirectories
    }

    @Test
    @Unroll
    void 'Outage page directory #outagePageDirectory.parent/#outagePageDirectory.name contains no subdirectories'(File outagePageDirectory) {

        given:
        final List<File> subFolders = listDirectDescendantDirectories(outagePageDirectory).collect { e -> return e.name}

        expect:
        !subFolders || subFolders.every {d -> allowedLanguageDirs.contains(d)}

        where:
        outagePageDirectory << outagePageDirectories
    }

    @Test
    @Unroll
    void '#outagePageFile.parent/#outagePageFile.name should be named index.html'(File outagePageFile) {

        expect:
        assert "index.html" == outagePageFile.name, "${outagePageFile.parent}/${outagePageFile.name}: Outage pages must be called 'index.html'"

        where:
        outagePageFile << outagePages
    }

    private static List<File> validateEnvironments(final List<String> environmentNames) {
        final List<File> existingEnvironmentDirectories = []
        final List<File> absentEnvironmentDirectories = []

        environmentNames.each { environmentName ->
            final File environmentDirectory = new File(environmentName)
            if(environmentDirectory.exists()) {
                existingEnvironmentDirectories << environmentDirectory
            }
            else {
                absentEnvironmentDirectories << environmentDirectory
            }
        }

        if(absentEnvironmentDirectories) {
            fail("Error, the specified environment directories do not exist: ${absentEnvironmentDirectories}")
        }

        LOGGER.info("Will validate environment directories: ${existingEnvironmentDirectories}")
        return existingEnvironmentDirectories
    }

    private static listOutagePages(final List<File> environmentDirectories) {
        final Closure<Stream<File>> getDescendantFiles = { File directory ->
            List<File> files = []
            directory.eachFileRecurse(FileType.FILES) { files.add(it) }
            return files.stream()
        }

        final List<File> outagePageFiles = environmentDirectories
                .stream()
                .flatMap(getDescendantFiles)
                .collect()
        return outagePageFiles
    }

    private static List<File> listOutagePageDirectories(final List<File> environmentDirectories) {
        final List<File> outagePageDirectories = environmentDirectories
                .stream()
                .flatMap({ File directory -> return listDirectDescendantDirectories.call(directory).stream() })
                .collect()

        return outagePageDirectories
    }
}
