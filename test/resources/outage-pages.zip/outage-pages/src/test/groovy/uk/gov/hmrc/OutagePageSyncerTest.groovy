package uk.gov.hmrc

import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model.DeleteObjectsRequest
import com.amazonaws.services.s3.model.ObjectListing
import com.amazonaws.services.s3.model.S3ObjectSummary
import com.amazonaws.services.s3.transfer.MultipleFileUpload
import com.amazonaws.services.s3.transfer.TransferManager
import spock.lang.Specification

import java.nio.file.Path
import java.nio.file.Paths

class OutagePageSyncerTest extends Specification {

    private OutagePageSyncer underTest

    private AmazonS3 amazonS3 = Mock(AmazonS3)

    private TransferManager transferManager = Mock(TransferManager)

    private ObjectListing objectListing = Mock(ObjectListing)

    private MultipleFileUpload multipleFileUpload = Mock(MultipleFileUpload)

    private OutagePagesLocalResolver outagePagesLocalResolver = Mock(OutagePagesLocalResolver)

    final String environment = "unit-test-environment"

    final String outagePageS3Bucket = "mdtp-shutter-switches"

    final String outagePagesS3SyncBasePath = "content"

    final Path environmentDirectory = Paths.get(environment)

    def setup() {
        underTest = new OutagePageSyncer(amazonS3,
                                         transferManager,
                                         outagePagesLocalResolver)
    }

    void "it should upload new local files to S3"() {
        setup:
        final List<Path> localOutagePages = [Paths.get("${environment}/service-1/index.html"),
                                             Paths.get("${environment}/service-2/index.html")]
        outagePagesLocalResolver.getOutagePageFiles(environmentDirectory) >> localOutagePages
        amazonS3.listObjects(outagePageS3Bucket, "content/${environment}") >> objectListing
        objectListing.objectSummaries >> []
        transferManager.uploadFileList(outagePageS3Bucket,
                                       "content/${environment}",
                                       environmentDirectory.toFile(),
                                       localOutagePages.collect(){it.toFile()}) >> multipleFileUpload

        when:
        underTest.syncOutagePages(environment,
                                  outagePageS3Bucket,
                                  outagePagesS3SyncBasePath)

        then:
        1 * multipleFileUpload.waitForCompletion()
        1 * transferManager.shutdownNow(true)
    }

    void "it should re-synchronise any files which exist both locally and remotely"() {
        setup:
        final S3ObjectSummary s3ObjectSummary1 = Mock(S3ObjectSummary)
        s3ObjectSummary1.key >> "content/${environment}/service-1/index.html"
        final S3ObjectSummary s3ObjectSummary2 = Mock(S3ObjectSummary)
        s3ObjectSummary2.key >> "content/${environment}/service-2/index.html"

        final List<Path> localOutagePages = [Paths.get("${environment}/service-1/index.html"),
                                             Paths.get("${environment}/service-2/index.html")]
        outagePagesLocalResolver.getOutagePageFiles(environmentDirectory) >> localOutagePages
        amazonS3.listObjects(outagePageS3Bucket, "content/${environment}") >> objectListing
        objectListing.objectSummaries >> [s3ObjectSummary1, s3ObjectSummary2]
        transferManager.uploadFileList(outagePageS3Bucket,
                                       "content/${environment}",
                                       environmentDirectory.toFile(),
                                       localOutagePages.collect(){it.toFile()}) >> multipleFileUpload

        when:
        underTest.syncOutagePages(environment,
                                  outagePageS3Bucket,
                                  outagePagesS3SyncBasePath)

        then:
        1 * multipleFileUpload.waitForCompletion()
        1 * transferManager.shutdownNow(true)
    }

    void "it should remove files from S3 which don't exist locally"()
    {
        setup:
        final S3ObjectSummary s3ObjectSummary1 = Mock(S3ObjectSummary)
        s3ObjectSummary1.key >> "content/${environment}/service-1/index.html"
        final S3ObjectSummary s3ObjectSummary2 = Mock(S3ObjectSummary)
        s3ObjectSummary2.key >> "content/${environment}/service-2/index.html"

        final List<Path> localOutagePages = []
        outagePagesLocalResolver.getOutagePageFiles(environmentDirectory) >> localOutagePages
        amazonS3.listObjects(outagePageS3Bucket, "content/${environment}") >> objectListing
        objectListing.objectSummaries >> [s3ObjectSummary1, s3ObjectSummary2]

        DeleteObjectsRequest deleteObjectsRequest
        1 * amazonS3.deleteObjects({
            deleteObjectsRequest = it
            it instanceof DeleteObjectsRequest
        })

        when:
        underTest.syncOutagePages(environment,
                                  outagePageS3Bucket,
                                  outagePagesS3SyncBasePath)

        then:

        deleteObjectsRequest.bucketName == outagePageS3Bucket
        2 == deleteObjectsRequest.keys.size()
        deleteObjectsRequest.keys.find() { it.key == "content/${environment}/service-1/index.html" }
        deleteObjectsRequest.keys.find() { it.key == "content/${environment}/service-2/index.html" }
        1 * transferManager.shutdownNow(true)
    }

}
