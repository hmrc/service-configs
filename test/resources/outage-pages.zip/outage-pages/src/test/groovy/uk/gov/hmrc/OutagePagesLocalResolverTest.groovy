package uk.gov.hmrc

import spock.lang.Shared
import spock.lang.Specification

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths

import static java.nio.file.Files.createDirectory
import static java.nio.file.Files.createFile
import static java.nio.file.Files.createTempDirectory

class OutagePagesLocalResolverTest extends Specification {

    @Shared
    private Path testDir

    private OutagePagesLocalResolver underTest

    def setup() {
        testDir = createTempDirectory("OutagePagesLocalResolverTest")
        underTest = new OutagePagesLocalResolver()
    }

    def cleanup() {
        Files.walk(testDir)
             .sorted(Comparator.reverseOrder())
             .map({it.toFile()})
             .forEach({it.delete()})
    }

    def "it should throw an exception if the specified environment directory doesn't exist"() {
        given:
        final String environment = "/foo/bar/non-existent-environment"
        final Path environmentDir = Paths.get(environment)

        when:
        underTest.getOutagePageFiles(environmentDir)

        then:
        FileNotFoundException fnfe = thrown()
        "Environment directory: '/foo/bar/non-existent-environment' does not exist." == fnfe.message

    }

    def "it should list all the outage page files for the specified environment"() {
        given:
        final String environment = "test-env-1"
        final Path environmentDir = createDirectory(testDir.resolve(environment))
        final Path serviceOneDir = createDirectory(environmentDir.resolve("service-one"))
        final Path serviceTwoDir = createDirectory(environmentDir.resolve("service-two"))
        final Path serviceOneOutagePage = createFile(serviceOneDir.resolve("index.html"))
        final Path serviceTwoOutagePage = createFile(serviceTwoDir.resolve("index.html"))

        when:
        final List<File> outagePageFiles = underTest.getOutagePageFiles(environmentDir)

        then:
        2 == outagePageFiles.size()
        outagePageFiles.contains(serviceOneOutagePage)
        outagePageFiles.contains(serviceTwoOutagePage)
    }
}
